El manual de instalación del proyecto se encuentra en la carperta webroot\manual\MU_ManualUsuario_Incideitor.pdf de este mismo proyecto
